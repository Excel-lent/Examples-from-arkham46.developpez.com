**************************************************
          VB modules pack for OpenGL
              ===   Version 0.6 ===
**************************************************
This pack is provided as-is, without any warranty
It's free for any use.
**************************************************
http://arkham46.developpez.com
**************************************************
v0.6 = 04/01/2019 = 64bits and openGL3 compatibility, integration of freeglut window in a form
v0.5 = 01/02/2010 = Added TGA texture loader (ModOpenGLTextureTGA.bas)
v0.4 = 13/11/2009 = Correction in clOpengGLFormAccess (Terminate was not raised due to a circulaar reference)
v0.3 = 10/11/2009 = Correction in classe modules of an openGL context creation erreur
v0.2 = 08/11/2009 = Change of ModOpenGLTools to make RemapVBFunctionToGLFunction work with VB6
v0.1 = 04/11/2009 = Initial version

